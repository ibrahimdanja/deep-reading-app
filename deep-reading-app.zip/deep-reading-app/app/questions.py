"""
Generates Socratic follow-up questions about a piece of reading, using the
free tier of the Gemini API. No paid plan needed — see README for how to get
a free key at https://aistudio.google.com
"""

import os
import requests

GEMINI_MODEL = "gemini-2.5-flash"  # fast + free-tier friendly
GEMINI_URL = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent"
)

PROMPT_TEMPLATE = """You are a Socratic tutor. Given the following short piece of
science writing, generate exactly 3 follow-up questions that force the reader
to think critically — not comprehension checks. Good question types:
- "Why might this be true, or what would have to be true for it to hold?"
- "What's the weakest part of this claim or argument?"
- "What would change your mind about this?"
- "What does this imply that the piece doesn't say directly?"

Avoid generic questions like "what did you learn" or "summarize this".
Return ONLY the 3 questions, one per line, no numbering, no preamble.

Title: {title}
Text: {summary}
"""


def generate_questions(title: str, summary: str) -> list[str]:
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY not set. Copy .env.example to .env and add your "
            "free key from https://aistudio.google.com"
        )

    prompt = PROMPT_TEMPLATE.format(title=title, summary=summary)

    response = requests.post(
        GEMINI_URL,
        params={"key": api_key},
        json={"contents": [{"parts": [{"text": prompt}]}]},
        timeout=30,
    )
    response.raise_for_status()
    data = response.json()

    text = data["candidates"][0]["content"]["parts"][0]["text"]
    questions = [q.strip("-• \t") for q in text.strip().split("\n") if q.strip()]
    return questions[:3]
