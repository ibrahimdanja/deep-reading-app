"""
Thin API layer over the existing pipeline (content.py, questions.py, storage.py)
so the web frontend can call it. Run with:
    uvicorn app.server:app --reload
"""

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from app.content import get_piece
from app.questions import generate_questions
from app.spaced_rep import ReviewState
from app.storage import save_entry

load_dotenv()

app = FastAPI()


class AnswerPayload(BaseModel):
    title: str
    summary: str
    url: str
    source: str
    questions: list[str]
    answers: list[str]


@app.get("/api/piece")
def api_get_piece():
    piece = get_piece()
    questions = generate_questions(piece["title"], piece["summary"])
    return {**piece, "questions": questions}


@app.post("/api/answer")
def api_save_answer(payload: AnswerPayload):
    review_state = ReviewState()
    save_entry(
        piece={
            "title": payload.title,
            "summary": payload.summary,
            "url": payload.url,
            "source": payload.source,
        },
        questions=payload.questions,
        answers=payload.answers,
        review_state=review_state,
    )
    return {"status": "saved"}


# Serve the frontend
app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
