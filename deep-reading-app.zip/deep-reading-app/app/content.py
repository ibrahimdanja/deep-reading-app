"""
Pulls short science pieces to read. Starts with arXiv abstracts (free, no API
key needed). Later we can add Aeon/Quanta/Nautilus via RSS the same way.
"""

import random
import feedparser

# A handful of broad categories to pull from. Add/remove as your taste narrows.
# Full list of arXiv categories: https://arxiv.org/category_taxonomy
ARXIV_CATEGORIES = [
    "physics.gen-ph",   # general physics
    "q-bio.NC",         # neuroscience
    "cs.AI",            # AI
    "physics.soc-ph",   # social physics / complex systems
]


def fetch_arxiv_piece(category: str | None = None) -> dict:
    """
    Fetch one recent abstract from arXiv as a short 'piece' to read.
    Returns a dict: {title, summary, url, source}
    """
    category = category or random.choice(ARXIV_CATEGORIES)
    feed_url = f"http://export.arxiv.org/rss/{category}"
    feed = feedparser.parse(feed_url)

    if not feed.entries:
        raise RuntimeError(f"No entries found for arXiv category '{category}'")

    entry = random.choice(feed.entries[:15])  # pick from the most recent batch

    # arXiv RSS summaries often include some HTML/formatting cruft — light cleanup
    summary = entry.summary.replace("\n", " ").strip()

    return {
        "title": entry.title.strip(),
        "summary": summary,
        "url": entry.link,
        "source": f"arXiv ({category})",
    }


def get_piece() -> dict:
    """
    Main entry point for the content pipeline. Right now this only knows about
    arXiv; this is the function to extend when adding more sources.
    """
    return fetch_arxiv_piece()
